<div align="center">

<img src="./assets/coding-banner.png" width="100%" alt="Coding workspace banner">

<br><br>

<img src="./assets/coding-animation.gif" width="75%" alt="Animated coding terminal">

<br><br>

# 👋 Hey, I'm Suhaib

### 💻 Information Technology Student · 🌱 Learning · 🚀 Building

<br>

<img src="https://skillicons.dev/icons?i=c,html,css,git,github,vscode&perline=6" alt="Tech stack">

</div>

---

## 🧑‍💻 About Me

I'm an **Information Technology student** currently building my programming fundamentals and exploring different areas of tech.

- 💻 Currently learning **C**
- 🧩 Practicing programming and problem solving
- 🌐 Exploring web development
- 🔧 Learning Git & GitHub
- 🚀 Building small projects as I learn
- 🌱 Slowly expanding my skills

---

<div align="center">

## ⚡ Current Focus

| 💻 Coding | 🧠 Problem Solving | 🚀 Projects |
|:---:|:---:|:---:|
| C Programming | Practice & Logic | Learning by Building |

</div>

---

## 🛠️ Tech I'm Learning

<div align="center">

<img src="https://skillicons.dev/icons?i=c,html,css,git,github,vscode&perline=6" alt="Technologies">

</div>

---

## 🚧 Projects

### 💻 C Practice
Small programs and exercises I'm writing while learning C.

### 🌐 Web Experiments
Simple HTML/CSS projects while getting comfortable with the web.

### 🔮 More Coming
As I learn more, this section will grow with real projects.

---

<div align="center">

## 📊 GitHub Journey

<img src="https://github-readme-stats.vercel.app/api?username=Suhaib-Tech&show_icons=true&hide_border=true&theme=github_dark&rank_icon=github" height="170" alt="GitHub stats">

<img src="https://streak-stats.demolab.com?user=Suhaib-Tech&theme=github-dark-blue&hide_border=true" height="170" alt="GitHub streak">

<br><br>

<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Suhaib-Tech&layout=compact&hide_border=true&theme=github_dark" height="150" alt="Top languages">

</div>

---

<div align="center">

## 🎯 2026

**Learn → Practice → Build → Improve**

<br><br>

<img src="https://komarev.com/ghpvc/?username=Suhaib-Tech&style=for-the-badge&color=1F6FEB&label=PROFILE+VIEWS" alt="Profile views">

</div>
